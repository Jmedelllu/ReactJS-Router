// contact page
function Contact (){
    return(
        <address>
            You can find me here:<br />
            Universitas Klabat<br />
            Jl. Arnold Mononutu, Airmadidi Bawah, Kec. Airmadidi, <br />
            Kabupaten Minahasa Utara, Sulawesi Utara 95371
        </address>
    );
}