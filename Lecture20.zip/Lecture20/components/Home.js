// default page
function Home (){
    return (
        <div>
            <h1>Welcome to Front-End Class !!</h1>
            <h3>How are you today?</h3>
        </div>
    );
}